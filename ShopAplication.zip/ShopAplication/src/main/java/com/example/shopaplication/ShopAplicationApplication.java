package com.example.shopaplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopAplicationApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShopAplicationApplication.class, args);
    }

}
