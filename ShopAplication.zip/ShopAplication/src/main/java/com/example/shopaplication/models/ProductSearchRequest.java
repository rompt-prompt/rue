package com.example.shopaplication.models;

public class ProductSearchRequest {
    private String title;
    private Float priceOt;
    private Float priceDo;
    private Integer categoryId;
    private String sorting;

    public ProductSearchRequest(String title, Float priceOt, Float priceDo, Integer categoryId, String sorting) {
        this.title = title;
        this.priceOt = priceOt;
        this.priceDo = priceDo;
        this.categoryId = categoryId;
        this.sorting = sorting;
    }

    public ProductSearchRequest() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Float getPriceOt() {
        return priceOt;
    }

    public void setPriceOt(Float priceOt) {
        this.priceOt = priceOt;
    }

    public Float getPriceDo() {
        return priceDo;
    }

    public void setPriceDo(Float priceDo) {
        this.priceDo = priceDo;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getSorting() {
        return sorting;
    }

    public void setSorting(String sorting) {
        this.sorting = sorting;
    }
}
