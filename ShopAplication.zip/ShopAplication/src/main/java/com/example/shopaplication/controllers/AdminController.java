package com.example.shopaplication.controllers;

import com.example.shopaplication.models.*;
import com.example.shopaplication.repositories.CategoryRepository;
import com.example.shopaplication.repositories.OrderRepository;
import com.example.shopaplication.repositories.PersonRepository;
import com.example.shopaplication.repositories.StatusRepository;
import com.example.shopaplication.services.OrderService;
import com.example.shopaplication.services.PersonService;
import com.example.shopaplication.services.ProductService;
import com.example.shopaplication.services.StatusService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Controller
public class AdminController {

    private final ProductService productService;
    private final OrderRepository orderRepository;
    private final OrderService orderService;
    private  final StatusService statusService;
    private final StatusRepository statusRepository;
    private final PersonService personService;
    private final PersonRepository personRepository;

    @Value("${upload.path}")
    private String uploadPath;

    private final CategoryRepository categoryRepository;

    public AdminController(ProductService productService, CategoryRepository categoryRepository, OrderRepository orderRepository, OrderService orderService, StatusService statusService, StatusRepository statusRepository, PersonService personService, PersonRepository personRepository) {
        this.productService = productService;
        this.categoryRepository = categoryRepository;
        this.orderRepository = orderRepository;
        this.orderService = orderService;
        this.statusService = statusService;
        this.statusRepository = statusRepository;
        this.personService = personService;
        this.personRepository = personRepository;
    }

    @GetMapping("admin/product/add")
    public String addProduct(Model model){
        model.addAttribute("product", new Product());
        model.addAttribute("category", categoryRepository.findAll());
        return "product/addProduct";
    }

    @PostMapping("/admin/product/add")
    public String addProduct(@ModelAttribute("product") @Valid Product product, BindingResult bindingResult, @RequestParam("file_one")MultipartFile file_one, @RequestParam("file_two")MultipartFile file_two, @RequestParam("file_three")MultipartFile file_three, @RequestParam("file_four")MultipartFile file_four, @RequestParam("file_five")MultipartFile file_five, @RequestParam("category") int category, Model model) throws IOException {
        Category category_db = (Category) categoryRepository.findById(category).orElseThrow();
        System.out.println(category_db.getName());
        if(bindingResult.hasErrors()){
            model.addAttribute("category", categoryRepository.findAll());
            return "product/addProduct";
        }

        if(!file_one.isEmpty()){
            File uploadDir = new File(uploadPath);
            if(!uploadDir.exists()){
                uploadDir.mkdir();
            }
            String uuidFile = UUID.randomUUID().toString();
            String resultFileName = uuidFile + "." + file_one.getOriginalFilename();
            file_one.transferTo(new File(uploadPath + "/" + resultFileName));
            Image image = new Image();
            image.setProduct(product);
            image.setFileName(resultFileName);
            product.addImageToProduct(image);
        }

        if(!file_two.isEmpty()){
            File uploadDir = new File(uploadPath);
            if(!uploadDir.exists()){
                uploadDir.mkdir();
            }
            String uuidFile = UUID.randomUUID().toString();
            String resultFileName = uuidFile + "." + file_two.getOriginalFilename();
            file_two.transferTo(new File(uploadPath + "/" + resultFileName));
            Image image = new Image();
            image.setProduct(product);
            image.setFileName(resultFileName);
            product.addImageToProduct(image);
        }

        if(!file_three.isEmpty()){
            File uploadDir = new File(uploadPath);
            if(!uploadDir.exists()){
                uploadDir.mkdir();
            }
            String uuidFile = UUID.randomUUID().toString();
            String resultFileName = uuidFile + "." + file_three.getOriginalFilename();
            file_three.transferTo(new File(uploadPath + "/" + resultFileName));
            Image image = new Image();
            image.setProduct(product);
            image.setFileName(resultFileName);
            product.addImageToProduct(image);
        }

        if(!file_four.isEmpty()){
            File uploadDir = new File(uploadPath);
            if(!uploadDir.exists()){
                uploadDir.mkdir();
            }
            String uuidFile = UUID.randomUUID().toString();
            String resultFileName = uuidFile + "." + file_four.getOriginalFilename();
            file_four.transferTo(new File(uploadPath + "/" + resultFileName));
            Image image = new Image();
            image.setProduct(product);
            image.setFileName(resultFileName);
            product.addImageToProduct(image);
        }

        if(!file_five.isEmpty()){
            File uploadDir = new File(uploadPath);
            if(!uploadDir.exists()){
                uploadDir.mkdir();
            }
            String uuidFile = UUID.randomUUID().toString();
            String resultFileName = uuidFile + "." + file_five .getOriginalFilename();
            file_five .transferTo(new File(uploadPath + "/" + resultFileName));
            Image image = new Image();
            image.setProduct(product);
            image.setFileName(resultFileName);
            product.addImageToProduct(image);
        }
        productService.saveProduct(product, category_db);
        return "redirect:/admin";
    }


    @GetMapping("/admin")
    public String admin(Model model)
    {
        model.addAttribute("products", productService.getAllProduct());
        return "admin";
    }

    @GetMapping("admin/product/delete/{id}")
    public String deleteProduct(@PathVariable("id") int id){
        productService.deleteProduct(id);
        return "redirect:/admin";
    }

    @GetMapping("admin/product/edit/{id}")
    public String editProduct(Model model, @PathVariable("id") int id){
        model.addAttribute("product", productService.getProductId(id));
        model.addAttribute("category", categoryRepository.findAll());
        return "product/editProduct";


    }

    @PostMapping("admin/product/edit/{id}")
    public String editProduct(@ModelAttribute("product") @Valid Product product, BindingResult bindingResult, @PathVariable("id") int id, Model model){
        if(bindingResult.hasErrors()){
            model.addAttribute("category", categoryRepository.findAll());
            return "product/editProduct";
        }
        productService.updateProduct(id, product);
        return "redirect:/admin";
    }

    @GetMapping("/admin-orders")
    public String getOders(Model model) {
        model.addAttribute("orders", orderRepository.findAll());
        model.addAttribute("statuses", statusRepository.findAll());
        return "admin/adminOrders";
    }

    @GetMapping("/admin-orders/search")
    public String getOdersSearch(@RequestParam String str, Model model) {
        model.addAttribute("orders", orderRepository.findAllByNumberEndsWith(str));
        model.addAttribute("statuses", statusRepository.findAll());
        return "admin/adminOrdersSearch";
    }
    @PostMapping("/admin-orders/change-status")
    public String changeStatus(@RequestParam("orderId") int orderId, @RequestParam("status") int status) {
        Order order = orderService.getOrderId(orderId);
        order.setStatus(statusService.getStatusId(status));
        orderRepository.save(order);
        return "redirect:/admin-orders";
    }

    @GetMapping("/admin-users")
    public String getUsers(Model model) {
        model.addAttribute("users", personService.getAllUsers());
        return "admin/adminUsers";
    }

    @PostMapping("/admin-users/change-role")
    public String changeRole(@RequestParam int id, @RequestParam String role) {
        Person person = personService.findById(id);
        person.setRole(role);
        personRepository.save(person);
        return "redirect:/admin-users";
    }
}
