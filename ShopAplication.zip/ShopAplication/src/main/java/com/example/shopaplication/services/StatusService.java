package com.example.shopaplication.services;

import com.example.shopaplication.models.Status;
import com.example.shopaplication.repositories.StatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class StatusService {
    private final StatusRepository statusRepository;

    public StatusService(StatusRepository statusRepository) {
        this.statusRepository = statusRepository;
    }

    public Status getStatusId(int id){
        Optional<Status> optionalStatus = statusRepository.findById(id);
        return optionalStatus.orElse(null);
    }
}
