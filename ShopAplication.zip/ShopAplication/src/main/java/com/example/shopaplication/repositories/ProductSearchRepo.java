package com.example.shopaplication.repositories;

import com.example.shopaplication.models.Product;
import com.example.shopaplication.models.ProductSearchRequest;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class ProductSearchRepo {
    private final EntityManager entityManager;

    public ProductSearchRepo(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    public List<Product> findAllByCriteria(
            ProductSearchRequest request
    ) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Product> criteriaQuery = criteriaBuilder.createQuery(Product.class);

        List<Predicate> predicates = new ArrayList<>();

        Root<Product> root = criteriaQuery.from(Product.class);
        if(request.getSorting().equals("ASC")) {
            criteriaQuery.orderBy(criteriaBuilder.asc(root.get("price")));
        }
        if(request.getSorting().equals("DESC")) {
            criteriaQuery.orderBy(criteriaBuilder.desc(root.get("price")));
        }

//        private String title;
//        private float priceOt;
//        private float priceDo;
//        private int categoryId;
        if(request.getTitle() != null) {
            Predicate titlePredicate = criteriaBuilder
                    .like(root.get("title"), "%" + request.getTitle() + "%");
            predicates.add(titlePredicate);
        }
        if(request.getPriceOt() != null & request.getPriceDo() == null) {
            Predicate priceOtPredicate = criteriaBuilder
                    .greaterThanOrEqualTo(root.get("price"), request.getPriceOt());
            predicates.add(priceOtPredicate);
        }
        if(request.getPriceOt() == null & request.getPriceDo() != null) {
            Predicate priceDoPredicate = criteriaBuilder
                    .lessThanOrEqualTo(root.get("price"), request.getPriceDo());
            predicates.add(priceDoPredicate);
        }
        if(request.getPriceOt() != null & request.getPriceDo() != null) {
            Predicate priceDoPredicate = criteriaBuilder
                    .between(root.get("price"), request.getPriceOt(), request.getPriceDo());
            predicates.add(priceDoPredicate);
        }
        if(request.getCategoryId() != null) {
            Predicate categoryPredicate = criteriaBuilder
                    .equal(root.get("category"), request.getCategoryId());
            predicates.add(categoryPredicate);
        }
        criteriaQuery.where(
                criteriaBuilder.and(predicates.toArray(new Predicate[0]))
        );

        TypedQuery<Product> query = entityManager.createQuery(criteriaQuery);
        return query.getResultList();
    }
}
