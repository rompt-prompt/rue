package com.example.shopaplication.controllers;

import com.example.shopaplication.models.Product;
import com.example.shopaplication.models.ProductSearchRequest;
import com.example.shopaplication.repositories.ProductRepository;
import com.example.shopaplication.repositories.ProductSearchRepo;
import com.example.shopaplication.services.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Controller
@RequestMapping("/product")
public class ProductController {

    private final ProductRepository productRepository;
    private  final ProductService productService;
    private final ProductSearchRepo productSearchRepo;

    public ProductController(ProductRepository productRepository, ProductService productService, ProductSearchRepo productSearchRepo) {
        this.productRepository = productRepository;
        this.productService = productService;
        this.productSearchRepo = productSearchRepo;
    }

    @GetMapping("")
    public String getAllProduct(Model model){
        model.addAttribute("products", productService.getAllProduct());
        return "/product/product";
    }

    @GetMapping("/info/{id}")
    public String infoProduct(@PathVariable("id") int id, Model model){
        model.addAttribute("product", productService.getProductId(id));
        return "/product/infoProduct";
    }

//    @PostMapping("/search")
//    public String productSearch(@RequestParam("search") String search, @RequestParam("ot") String ot, @RequestParam("do") String Do, @RequestParam(value = "price", required = false, defaultValue = "") String price, @RequestParam(value = "contract", required = false, defaultValue = "")String contract, Model model){
//        model.addAttribute("products", productService.getAllProduct());
//
//        if(!ot.isEmpty() & !Do.isEmpty()){
//            if(!price.isEmpty()){
//                if(price.equals("sorted_by_ascending_price")) {
//                    if (!contract.isEmpty()) {
//                        if (contract.equals("furniture")) {
//                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 1));
//                        } else if (contract.equals("appliances")) {
//                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 3));
//                        } else if (contract.equals("clothes")) {
//                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 2));
//                        }
//                    } else {
//                        model.addAttribute("search_product", productRepository.findByTitleOrderByPriceAsc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do)));
//                    }
//                } else if(price.equals("sorted_by_descending_price")){
//                    if(!contract.isEmpty()){
//                        System.out.println(contract);
//                        if(contract.equals("furniture")){
//                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 1));
//                        }else if (contract.equals("appliances")) {
//                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 3));
//                        } else if (contract.equals("clothes")) {
//                            model.addAttribute("search_product", productRepository.findByTitleAndCategoryOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do), 2));
//                        }
//                    }  else {
//                        model.addAttribute("search_product", productRepository.findByTitleOrderByPriceDesc(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do)));
//                    }
//                }
//            } else {
//                model.addAttribute("search_product", productRepository.findByTitleAndPriceGreaterThanEqualAndPriceLessThanEqual(search.toLowerCase(), Float.parseFloat(ot), Float.parseFloat(Do)));
//            }
//        } else {
//            model.addAttribute("search_product", productRepository.findByTitleContainingIgnoreCase(search));
//        }
//
//        model.addAttribute("value_search", search);
//        model.addAttribute("value_price_ot", ot);
//        model.addAttribute("value_price_do", Do);
//        return "/product/product";
//
//    }

    @PostMapping("/search")
    public String productSearch(
            @RequestParam(value = "title", required = false, defaultValue = "") String title,
            @RequestParam(value = "priceOt", required = false, defaultValue = "") String priceOt,
            @RequestParam(value = "priceDo", required = false, defaultValue = "") String priceDo,
            @RequestParam(value = "categoryId", required = false, defaultValue = "") String categoryId,
            @RequestParam(value = "sorting", required = false, defaultValue = "ASC") String sorting,
            Model model)
    {
        ProductSearchRequest request = new ProductSearchRequest();
        if(!title.isEmpty()) { request.setTitle(title); }
        if(!priceOt.isEmpty()) { request.setPriceOt(Float.parseFloat(priceOt)); }
        if(!priceDo.isEmpty()) { request.setPriceDo(Float.parseFloat(priceDo)); }
        if(!categoryId.isEmpty()) { request.setCategoryId(Integer.parseInt(categoryId)); }
        request.setSorting(sorting);

        List<Product> queryResult = productSearchRepo.findAllByCriteria(request) ;

        model.addAttribute("products", productService.getAllProduct());
        model.addAttribute("search_product", queryResult);


        model.addAttribute("value_title", title);
        model.addAttribute("value_priceOt", priceOt);
        model.addAttribute("value_priceDo", priceDo);
        return "/product/product";

    }
}
