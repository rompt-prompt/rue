package com.example.shopaplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopAplicationApplicationTests {

    @Test
    void contextLoads() {
    }

}
